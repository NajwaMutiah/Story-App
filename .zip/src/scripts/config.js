const CONFIG = {
  BASE_URL: 'https://story-api.dicoding.dev/v1',
  MAPBOX_ACCESS_TOKEN: 'YOUR_MAPBOX_TOKEN_HERE', // Optional, untuk mapbox
  DEFAULT_LAT: -6.2088,
  DEFAULT_LNG: 106.8456,
};

export default CONFIG;